stores = {

    printed: function ( id ) {
        var data = [{C_PRINTED:1}];
//		console.log( SOA004Client.post( id , data ) );
        SOA004Client.post( id , data, function( json ) {console.log( json );} );
    },

    picked: function ( id ) {
        var data = [{C_PICKED:1}];
//		console.log( SOA004Client.post( id , data ) );
        SOA004Client.post( id , data, function( json ) {console.log( json );} );
    },

    getUrlParams: function (url) {
        consolelog("getUrlParams:"+location.href);
        var queryString = location.href;
//        var queryString = url.split("?")[1];
        if ( queryString !== undefined ) {
            var keyValuePairs = queryString === undefined ? "" : queryString.split("&");
            var keyValue, params = {};
            keyValuePairs.forEach(function(pair) {
                keyValue = pair.split("=");
                params[keyValue[0]] = decodeURIComponent(keyValue[1]).replace("+", " ");
            });
        }
        return params
    },
    getsite : function (qv) {
        var qv= window.location.href;
        params = stores.getUrlParams(qv);
        
        consolelog("Site"+(params === undefined ? "" :params['site']));
        consolelog("Location"+(params === undefined ? "" : params['location']));
        
        qv = window.location.search.substring(1).split( "&" );
			for( var i=0; i < qv.length; i++ ) {
					var p = qv[i].split( "=" );
						if( p[0].toLowerCase() == 'siteid' ) this.site = p[1].toUpperCase();
						if( p[0].toLowerCase() == 'siteid' ) this.loc =  p[1].toUpperCase();
					}
		}
    
}
