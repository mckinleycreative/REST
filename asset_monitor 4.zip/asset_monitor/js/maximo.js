maximo = {

    printed: function (id) {
        var data = [{C_PRINTED:1}];
		console.log( SOA004Client.post( id , data ) );
        SOA004Client.post(id , data, function( json ) {console.log( json );});
    },

    picked: function (id) {
        var data = [{C_PICKED:1}];
		console.log( SOA004Client.post( id , data ) );
        SOA004Client.post( id , data, function( json ) {console.log( json );} );
    },

	startTime: function () {
			var today = new Date();
			var h = today.getHours();
			var m = today.getMinutes();
			var s = today.getSeconds();
			m = maximo.checkTime(m);
			s = maximo.checkTime(s);
			document.getElementById('datetime').innerHTML = " Asset Status          "+
			h + ":" + m + ":" + s;
			var t = setTimeout(maximo.startTime, 500);
		},

    compile: function ( curr ) {
            var currdescription = curr.LOCATIONS[0].DESCRIPTION;
					currdescription += curr.FAILURECODE[0].DESCRIPTION;
                    currdescription += curr.ASSETNUM;
//					console.log('desc:'+currdescription);
			return currdescription;
		},

	checkTime: function (i) {
			if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
			return i;
		},
    
    set: function (id, val) {
			var el = document.getElementById(id);
			if( !el ) return;
			el.innerHTML = val;
		},
    
    daysBetween: function  (date1, date2) {
            // Get 1 day in milliseconds
            var one_day=1000*60*60;
            var one_hour=1000*60*60;
            var one_min=1000*60;
            var mins;
            var hours;
          // Convert both dates to milliseconds
          // Calculate the difference in milliseconds
          // Convert back to days and return
            mins = (date2.getTime()-date1.getTime())/one_min;
            mins = Math.round(mins);
            hours = (mins/60.0);
            hours = Math.round(hours);
            mins = mins - hours*60.0;
            if ( hours == 0 ) {
                downtime = mins+"m";
            }else if ( hours > 47 ) {
                downtime = Math.round(hours/2.4)/10.0+"d";
			} else {
                downtime = hours+"h";
            }
          return downtime;
        },
    
       outputconsole: function  ( text, json ){
            var start = 0;
            var allrecords  = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET.length;
            var i = 0;
            var records =allrecords-1;
		
            for( i=start ; i < allrecords ; ++i ) {
				curr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i];
				console.log(text+"::"+compile(curr));
			};
			console.log("===================");
		},
    
       sortbydept: function  ( json ){
            var start = 0;
            var allrecords  = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET.length;
            var swap = true;
            var endstop = 0;
            var endstart = 0;
            var i = 0;
            var records =allrecords-1;

//			maximo.outputconsole ( "dirty", json );

            for( i=start ; i < allrecords ; ++i ) {
				curr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i];
				curr.LOCATIONS[0].DESCRIPTION = curr.LOCATIONS === undefined ? "Unknown": curr.LOCATIONS[0].DESCRIPTION.replace('Mine ','').replace(' Fleet','').replace(' Light','').replace(' Vehicles','');
                curr.PRIORITY = curr.PRIORITY === undefined ? 4 : curr.PRIORITY;
//				.replace(' Equipment','').replace('Mobile ','').replace('Equipment ','');
                json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i] = curr;
			};
			maximo.outputconsole ( "clean", json );
            while (  swap ) {
                swap = false;
                for( i=start ; i < records ; ++i ) {
                    curr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i];
                    nextcurr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i+1];
                    var currdescription = compile ( curr );
                    var nextdescription = compile ( nextcurr );
                    if ( currdescription>nextdescription) {
                        swap= true
                        endstop=i;
                        json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i+1] = curr;
						json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i] = nextcurr;
//						displaytable(json);
                    }
                }
//				maximo.outputconsole ("mid:"+start+":"+endstop, json );
				records--;
//                records--;
                endstart = endstop-1;
				if ( !swap) break;
                swap=false;
                for( i=records ; i > start ; --i ) {
                    curr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i];
                    nextcurr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i-1];
                    var currdescription = compile ( curr );
                    var nextdescription = compile ( nextcurr );
                    if ( currdescription<nextdescription) {
                        swap= true
                        endstop=i;
                        json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i-1] = curr;
						json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i] = nextcurr;
                    }
                }
//                start++;
//				maximo.outputconsole ("end:"+start+":"+endstop, json );
            }
			maximo.outputconsole ( "final", json );
        },
    
    	displaytable: function  ( json ) {
            var tr = null;
            var displayall = true;
            var assetupcount=0;
            var assetdowncount=0;
            var assetservice=0;
            var d = new Date();
            maximo.set( "lastupdated", d.toLocaleString());
            var toptbl = null;
            var toptbl = document.getElementById( "tgt" );
            tblhead = toptbl.getElementsByTagName("thead")[0];
            tbl = toptbl.getElementsByTagName("tbody")[0];

			var assetrecords = json.QueryREST_ASSETResponse.rsCount;
			if ( assetrecords == 0 ) return;
			var assetcolums  = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET.length;
			var sectionname = null;
			var oldsectionname = null;
			var nocolumns = 0;
			var found = false;
			var td =null;

	        tablelength = toptbl.rows.length;
			for (var i = 0 ; i <tablelength; i++) {
				toptbl.deleteRow(0);
			}
            // start rebuild the header with the single version of the description
            th = tblhead.insertRow(0);

			if (  assetrecords >0 ) {
					// addtion column for the department field
					td = th.insertCell(-1);td.innerHTML = "Department";
					for( i=0; i < assetcolums ; i++ ) {
						var curr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i];
						if ( curr.PRIORITY <= chosenpriority && (curr.ISRUNNING == displayall || displayall) ) {
							sectionname = curr.FAILURECODE[0].DESCRIPTION;
							if ( nocolumns>0 ){
								var HeaderCells = toptbl.rows.item(0).cells;
								//gets cells of current row
								var cellLength = HeaderCells.length;
								found = false;
								for ( var j = 0; j<cellLength ; j++ ) {
									var cellVal = HeaderCells.item(j).innerHTML;
									if ( sectionname === cellVal)  {
										found = true;
									}
								}
							}
							// add them to the column
							if ( !found ){
								td = th.insertCell();
								td.innerHTML = sectionname;
								nocolumns += 1;
								oldsectionname= sectionname;
							}
						}
					}
					// run down through the cells with the logic of using the "department" field as a sort field
					HeaderCells = toptbl.rows.item(0).cells;
					for( i=0; i < assetcolums ; i++ ) {
						var curr = json.QueryREST_ASSETResponse.REST_ASSETSet.ASSET[i];
                        ass = curr.ASSETNUM ;
                        ass += chosenpriority != 1 ? "("+curr.PRIORITY+")" : "";
						if ( curr.PRIORITY <= chosenpriority && ( curr.ISRUNNING == displayall || displayall) ) {
						sectionname = curr.FAILURECODE[0].DESCRIPTION;
	//                    department = curr.LOCATION === undefined ? "Unknown" : curr.LOCATIONS[0].DESCRIPTION.replace('Mine ','').replace(' Fleet','').replace(' Light','').replace(' Vehicles','');
						department = curr.LOCATIONS[0].DESCRIPTION;
						found = false;
						// find the next available slot
						var currdept;
						var locald;
						for ( k=1;k<tbl.rows.length;++k){
							if ( !found ){
								deptlabel = tbl.rows.item(k).cells;
								currdept = deptlabel.item(0).innerHTML;
								if ( department == currdept) {
									for (l = 0; l < HeaderCells.length; l++) {
										currsection = HeaderCells.item(l).innerHTML;
										if ( sectionname == currsection ) {
											if ( deptlabel.item(l).innerHTML.length == 0 ) {
                                                // no entry in the cell so update it with current info
												if ( curr.ISRUNNING ){
													deptlabel.item(l).className="assetup";
													assetupcount += 1;
												} else {
													if ( curr.WORKORDER ) {
														if ( curr.WORKORDER[0].WORKTYPE === "PMP") {
															deptlabel.item(l).className="assetservice";
															assetservice+=1;
														} else {
															assetdowncount += 1;
															deptlabel.item(l).className="assetdown"+curr.PRIORITY;
														}
													} else {
														deptlabel.item(l).className="assetdown"+curr.PRIORITY;
														assetdowncount += 1;
													}
												}
												if ( curr.ASSETSTATUS ) {
													locald = new Date(curr.ASSETSTATUS[0].CHANGEDATE);
												} else {
													locald = new Date(curr.CHANGEDATE);
												}
												var downtime = maximo.daysBetween(locald,d);
												deptlabel.item(l).innerHTML = ass+"  "+downtime;
                                                found = true;
												break;
											}
										}
									}
								}
							}
						}

						if ( !found ){
							tr = tbl.insertRow(-1);
							td = tr.insertCell( -1 );td.innerHTML = department;
              td.className=department.toLowerCase();

							if( department == currdept ) td.style.visibility = "hidden";
							currdept=department;
							for ( var j = 1; j<cellLength ; j++ ) {
								var cellVal = HeaderCells.item(j).innerHTML;
                td = tr.insertCell();
								td.className=department.toLowerCase();
								if ( sectionname === cellVal)  {
									if ( curr.ISRUNNING ){
										td.className="assetup";
										assetupcount += 1;
									} else {
										if ( curr.WORKORDER ) {
											if ( curr.WORKORDER[0].WORKTYPE === "PMP") {
													td.className="assetservice";
													assetservice+=1;
												}else {
													assetdowncount += 1;
													td.className="assetdown"+curr.PRIORITY;
												}
										}else {
											td.className="assetdown"+curr.PRIORITY;
											assetdowncount += 1;
										}
									}
									if ( curr.ASSETSTATUS ) {
										locald = new Date(curr.ASSETSTATUS[0].CHANGEDATE);
									} else {
										locald = new Date(curr.CHANGEDATE);
									}
									var downtime = maximo.daysBetween(locald,d);
									td.innerHTML = ass+"  "+downtime;
								}
							}
						}
					}
				}
				maximo.set("assetupcount",assetupcount);
				maximo.set("assetdowncount",assetdowncount);
				maximo.set("assetservice",assetservice);
				}
		}




}
