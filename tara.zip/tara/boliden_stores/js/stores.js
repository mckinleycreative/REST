stores = {

    printed: function ( id ) {
        var data = [{C_PRINTED:1}];
//		console.log( SOA004Client.post( id , data ) );
        SOA004Client.post( id , data, function( json ) {console.log( json );} );
    },

    picked: function ( id ) {
        var data = [{C_PICKED:1}];
//		console.log( SOA004Client.post( id , data ) );
        SOA004Client.post( id , data, function( json ) {console.log( json );} );
    },

    getsite : function () {
			var qv = window.location.search.substring(1).split( "&" );
			for( var i=0; i < qv.length; i++ ) {
					var p = qv[i].split( "=" );
						if( p[0].toLowerCase() == 'siteid' ) this.site = p[1].toUpperCase();
						if( p[0].toLowerCase() == 'siteid' ) this.loc =  p[1].toUpperCase();
					}
		}
}
